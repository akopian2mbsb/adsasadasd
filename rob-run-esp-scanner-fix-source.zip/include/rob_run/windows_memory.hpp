#pragma once

#include "rob_run/geometry.hpp"

#ifdef _WIN32
namespace rob_run {
// Owns a read-only Windows process handle. Does not find or start a process.
class WindowsMemoryReader final : public MemoryReader {
public:
    static std::optional<WindowsMemoryReader> open(std::uint32_t process_id);
    ~WindowsMemoryReader() override;
    WindowsMemoryReader(const WindowsMemoryReader&) = delete;
    WindowsMemoryReader& operator=(const WindowsMemoryReader&) = delete;
    WindowsMemoryReader(WindowsMemoryReader&& other) noexcept;
    WindowsMemoryReader& operator=(WindowsMemoryReader&& other) noexcept;
    bool read(Address address, void* destination, std::size_t size) const override;
private:
    explicit WindowsMemoryReader(void* handle) : handle_(handle) {}
    void* handle_;
};
} // namespace rob_run
#endif
