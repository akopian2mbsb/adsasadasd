#pragma once

#include "rob_run/geometry.hpp"
#include <array>

namespace rob_run {

enum class Joint : std::size_t {
    pelvis, spine, chest, neck, head,
    left_shoulder, left_elbow, left_hand, right_shoulder, right_elbow, right_hand,
    left_hip, left_knee, left_ankle, left_foot, right_hip, right_knee, right_ankle, right_foot,
    count
};
constexpr std::size_t joint_count = static_cast<std::size_t>(Joint::count);
using JointAddresses = std::array<std::optional<Address>, joint_count>;
using Skeleton = std::array<std::optional<Vec3>, joint_count>;
struct EspLine { Vec2 from; Vec2 to; };

// Unreadable bones are omitted; addresses must refer to managed Transforms.
Skeleton read_skeleton(const MemoryReader& memory, const JointAddresses& joints);
// Returns segments whose endpoints both project in front of the camera. The caller
// clips off-screen lines to the viewport and renders them.
std::vector<EspLine> skeleton_lines(const Skeleton& skeleton, const Camera& camera,
                                    float width, float height);
} // namespace rob_run
