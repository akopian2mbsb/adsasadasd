#pragma once
#include "rob_run/game_state.hpp"
namespace rob_run {
struct EspFrame { Camera camera; std::vector<Vec3> positions; };
// Rejects incomplete session data; skips the local character and invalid entries.
std::optional<EspFrame> read_esp_frame(const MemoryReader& memory, Address unity_entry);
}
