#pragma once

#include <cstddef>
#include <cstdint>
#include <optional>
#include <vector>

namespace rob_run {

using Address = std::uint64_t;

// Implementations must return false unless the entire range was read.
class MemoryReader {
public:
    virtual ~MemoryReader() = default;
    virtual bool read(Address address, void* destination, std::size_t size) const = 0;
};

struct Vec3 { float x, y, z; };
struct Vec2 { float x, y; };
struct Quaternion { float x, y, z, w; };
struct TransformTRS {
    float position[4];
    float rotation[4];
    float scale[4];
};
static_assert(sizeof(TransformTRS) == 0x30, "unexpected TRS layout");

struct Camera {
    Vec3 position;
    Vec3 right;
    Vec3 up;
    Vec3 forward;
    float vertical_fov_degrees;
};

// Each offset is added to the previous address before reading a 64-bit pointer.
std::optional<Address> follow_pointers(const MemoryReader& memory, Address start,
                                       const std::vector<Address>& offsets);

// Reads the supplied Unity hierarchy layout and validates the native pointer at the
// transform's index. Returns no value on malformed or unreadable data.
std::optional<Vec3> bone_world_position(const MemoryReader& memory, Address managed_transform);

// Projects with the current camera basis. Off-screen coordinates are retained so
// callers can clip line segments. Points behind or too near the camera are rejected.
std::optional<Vec2> project(const Camera& camera, Vec3 world, float width, float height);

} // namespace rob_run
