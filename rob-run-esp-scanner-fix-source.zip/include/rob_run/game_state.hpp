#pragma once

#include "rob_run/geometry.hpp"
#include <utility>

namespace rob_run {

// Addresses are transient. Resolve again after a session or scene change.
struct BattleState {
    Address battle_model;
    Address entities_model;
    Address characters_dictionary;
    Address local_character;
};
struct BattleViews {
    Address entities_updater;
    Address character_views_dictionary;
    Address aim_updater;
    Address camera_brain;
};

// UnityEntry must be a current, already located managed instance. A null battle,
// missing local player, or an unreadable chain returns no state.
std::optional<BattleState> read_battle_state(const MemoryReader& memory, Address unity_entry);

// BattleUpdater must be a current, already located managed instance. Its battle
// and entity links are checked against state before any view pointers are returned.
std::optional<BattleViews> read_battle_views(const MemoryReader& memory, const BattleState& state,
                                             Address battle_updater);

// Derives the active BattleUpdater from a located UnityEntry. Checks cross-links.
std::optional<BattleViews> read_entry_views(const MemoryReader& memory, const BattleState& state,
                                            Address unity_entry);

// Reads BattleCameraModel basis and Cinemachine vertical FOV. Both addresses must
// be from the same active battle; a missing or implausible camera is rejected.
std::optional<Camera> read_camera(const MemoryReader& memory, const BattleState& state,
                                  const BattleViews& views);

// Snapshot of an IL2CPP Dictionary<int, object> using the reported x64 layout.
// Rejects unreadable data and changed headers; it is not an atomic snapshot.
using DictionaryEntry = std::pair<std::int32_t, Address>;
std::optional<std::vector<DictionaryEntry>> read_entity_dictionary(const MemoryReader& memory,
                                                                    Address dictionary);
} // namespace rob_run
