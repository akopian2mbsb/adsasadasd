#pragma once
#include <cstdint>

// Build 26807668: fields checked against the supplied offset report where available.
namespace rob_run::offsets {
inline constexpr std::uint64_t unity_entry_game = 0x28;
inline constexpr std::uint64_t game_model = 0xd0;
inline constexpr std::uint64_t battle_model = 0x10;
inline constexpr std::uint64_t rotation_input = 0x40;
inline constexpr std::uint64_t battle_entities = 0x90;
inline constexpr std::uint64_t aim_target = 0x198;
inline constexpr std::uint64_t connection_status = 0x218;
inline constexpr std::uint64_t camera_model = 0x358;
inline constexpr std::uint64_t character_slots = 0x4d0;
inline constexpr std::uint64_t world_entities = 0x60;
inline constexpr std::uint64_t battle_characters = 0x18;
// Root and some layout details still derive from the prior SDK and require live verification.
inline constexpr std::uint64_t entities_player = 0xd0;
inline constexpr std::uint64_t player_server_model = 0x20;
inline constexpr std::uint64_t updater_entities = 0x90;
inline constexpr std::uint64_t updater_battle = 0xe0;
inline constexpr std::uint64_t updater_aim = 0x1c0;
inline constexpr std::uint64_t entities_updater_model = 0x18;
inline constexpr std::uint64_t aim_updater_entities = 0x30;
inline constexpr std::uint64_t character_shot_args = 0xf8;
inline constexpr std::uint64_t character_id = 0x38;
inline constexpr std::uint64_t character_transform = 0x58;
inline constexpr std::uint64_t character_skeleton = 0x138;
inline constexpr std::uint64_t entities_updater_views = 0x110;
inline constexpr std::uint64_t aim_updater_brain = 0x48;
inline constexpr std::uint64_t brain_fov = 0xb0;
inline constexpr std::uint64_t brain_dutch = 0xc0;
inline constexpr std::uint64_t brain_raw_position = 0xfc;
inline constexpr std::uint64_t brain_raw_orientation = 0x108;
inline constexpr std::uint64_t brain_position_correction = 0x128;
inline constexpr std::uint64_t brain_orientation_correction = 0x134;
} // namespace rob_run::offsets
