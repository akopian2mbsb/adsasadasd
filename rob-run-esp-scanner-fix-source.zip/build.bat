@echo off
setlocal
cd /d "%~dp0"
set "CMAKE=cmake"
where cmake >nul 2>nul
if errorlevel 1 (
  set "VSWHERE=%ProgramFiles(x86)%\Microsoft Visual Studio\Installer\vswhere.exe"
  if not exist "%ProgramFiles(x86)%\Microsoft Visual Studio\Installer\vswhere.exe" goto missing
  for /f "usebackq tokens=*" %%i in (`"%ProgramFiles(x86)%\Microsoft Visual Studio\Installer\vswhere.exe" -latest -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath`) do set "VSROOT=%%i"
  if not defined VSROOT goto missing
  call set "CMAKE=%%VSROOT%%\Common7\IDE\CommonExtensions\Microsoft\CMake\CMake\bin\cmake.exe"
  call if not exist "%%CMAKE%%" goto missing
)
"%CMAKE%" -S . -B build -A x64 -DBUILD_TESTING=OFF
if errorlevel 1 goto fail
"%CMAKE%" --build build --config Release
if errorlevel 1 goto fail
if not exist dist mkdir dist
copy /y "build\Release\rob_run_overlay.exe" "dist\rob_run_overlay.exe" >nul
if errorlevel 1 goto fail
echo Build complete: dist\rob_run_overlay.exe
pause
exit /b 0
:missing
echo Install Visual Studio 2022 Build Tools with Desktop development with C++ and CMake.
pause
exit /b 1
:fail
echo Build failed. Read the errors above.
pause
exit /b 1
