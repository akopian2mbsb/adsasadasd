<!-- coderabbit-ai-generated:v1 -->

<!-- coderabbit-ai-generated:v1 -->

<!-- coderabbit-ai-generated-section:v1:295846a5e1f1b390f86b6fcb720b12b7b64ca9aa1c1a31a4dcb8928df0cd0afe -->

# ROB RUN external ESP

<!-- /coderabbit-ai-generated:v1 -->

<!-- coderabbit-ai-generated:v1 -->

<!-- coderabbit-ai-generated-section:v1:cf57c1a3819c92875cc1674b4ae9c5c2774147a7c1e42a890d4b7b92f2401564 -->

<!-- coderabbit-ai-generated:v1 -->

<!-- coderabbit-ai-generated-section:v1:e990f2031a9c0c3cdf21d53d8933fa9633b44c7fdf1744f94d3558da78ee29c3 -->

This is an experimental Windows external ESP based on the supplied build 26807668 offset report. Some root and native layouts still come from [SDK build 26726105](https://github.com/InsideExploit/rob-run-sdk/tree/1916b0f7e5e955a7870b796a7c64c3323c3a6e1d/26726105).

<!-- /coderabbit-ai-generated:v1 --> <!-- coderabbit-ai-generated:v1 -->

<!-- coderabbit-ai-generated-section:v1:cf628a0e74e028e7ccad1cc86722c2b455b8ff5833c6c9a7a79583dff775d396 -->

<!-- coderabbit-ai-generated:v1 -->

<!-- coderabbit-ai-generated-section:v1:d0b4989b00c2d549c4eae1e6c18cac66786b4481d3950ff445df31e421dd0f85 -->

The executable scans for the running game, reads entities and displays estimated player boxes in a click-through overlay. It has not been tested against a live game; aimbot and skeleton ESP are not implemented.

<!-- /coderabbit-ai-generated:v1 -->

<!-- /coderabbit-ai-generated:v1 -->

<!-- /coderabbit-ai-generated:v1 -->

## Build and test

<!-- coderabbit-ai-generated:v1 -->

<!-- coderabbit-ai-generated-section:v1:8a198dd1daef8019329aad5477e5a3b7f1803e0540f4415b4e19d20094449d10 -->

Install Visual Studio 2022 or its Build Tools with **Desktop development with C++**, including CMake. Extract the ZIP and double-click `build.bat`. The executable is written to `dist\rob_run_overlay.exe`.

<!-- coderabbit-ai-generated:v1 -->

<!-- coderabbit-ai-generated-section:v1:a3073ab3874f771f4704500b5045bf5bed8477634f1ba184b050db246a69dea7 -->

Start ROB RUN in windowed or borderless mode and join a match, then run the executable. The menu enables or disables boxes and can retry scanning. Close the menu to exit. The app requires the supplied GameAssembly.dll and metadata hashes before it scans. The status distinguishes memory access, class and instance failures; use Rescan after joining a match.

Medal integration is not included. The overlay uses a separate Windows window.

<!-- /coderabbit-ai-generated:v1 -->

For tests in a Visual Studio developer command prompt, run `cmake -S . -B build -A x64`, `cmake --build build --config Release`, then `ctest --test-dir build -C Release --output-on-failure`.

<!-- /coderabbit-ai-generated:v1 -->

## Integration still needed

<!-- coderabbit-ai-generated:v1 -->

<!-- coderabbit-ai-generated-section:v1:1474a233ff458aa825945f6a466fd0edbbb47965de886e9468827736c61ae0d1 -->

<!-- coderabbit-ai-generated:v1 -->

<!-- coderabbit-ai-generated-section:v1:d024dbbb3421d7c51e0baab9c8b295cb793269d28c3912bb5676788fe1f93d81 -->

<!-- coderabbit-ai-generated:v1 -->

<!-- coderabbit-ai-generated-section:v1:f029e2a3b667b8aca76d1ae563acfb9181ddee414b08a97921785a47ff6bf715 -->

- The scanner searches readable process memory for a UnityEntry instance, then checks the battle, local character, dictionary and camera links. Process access and the scanner have not been tested in the live game.

<!-- /coderabbit-ai-generated:v1 -->

<!-- /coderabbit-ai-generated:v1 -->
<!-- coderabbit-ai-generated:v1 -->

<!-- coderabbit-ai-generated-section:v1:4673edfbb9fbe649758056323ff68cfae06b65118e394a149af14a1d899ae727 -->

- Verify the dictionary layout and rig names against the actual client. The x64 dictionary parser uses a layout reported by [public source](https://github.com/mihaq0/opensource/blob/2521b464901d292aca193d94fb38b3bfaa99c7fc/Reader.cs); the SDK dump lists generic offsets as zero. Resolve the generic `_value` field before implementing aim.

<!-- /coderabbit-ai-generated:v1 -->
- The SDK lists ShotArgsModel at `BattleCharacterModel + 0xF8`; this differs from the supplied private-model chain and has not been verified in a live game.
<!-- coderabbit-ai-generated:v1 -->

<!-- coderabbit-ai-generated-section:v1:133e663e185acc0f32a13a5ee5a75a00bd161fc3ab2545fe8c4dcae3bcc9c484 -->

<!-- coderabbit-ai-generated:v1 -->

<!-- coderabbit-ai-generated-section:v1:17aa8dbb91eb7cb607c139161e401ddc5dc3a6b0aec680811faeb5c181e0aefd -->

<!-- coderabbit-ai-generated:v1 -->

<!-- coderabbit-ai-generated-section:v1:5e834bb24fc62803e5e78a187320a0102ec1cd54253ac031690bc8e4bfb65954 -->

- Verify the root, dictionary, camera basis and FOV together in the live build. Add skeleton drawing and aimbot separately if those features are required.

<!-- /coderabbit-ai-generated:v1 -->
- The supplied transform hierarchy count offset is `0x10`; [public source](https://github.com/mihaq0/opensource/blob/2521b464901d292aca193d94fb38b3bfaa99c7fc/Reader.cs) uses `0x38`. The library currently follows the supplied `0x10` and neither layout has been verified in the live game.

<!-- /coderabbit-ai-generated:v1 -->

<!-- /coderabbit-ai-generated:v1 -->

<!-- /coderabbit-ai-generated:v1 -->

<!-- coderabbit-ai-generated:v1 -->

<!-- coderabbit-ai-generated-section:v1:b26c4431690649ae60dfc41b7303e097d8a9d61751f8f66dea3f457ffa9ae367 -->

`MemoryReader` must read the full requested range or report failure. `WindowsMemoryReader::open` opens a provided process ID for read-only access; it does not locate a process or bypass process restrictions. The hierarchy arrays are read as native x64 data according to the supplied layout. `project` expects a final camera position and right/up/forward basis; it does not derive the basis from Cinemachine quaternions. `skeleton_lines` returns coordinates for a renderer and omits segments with missing or behind-camera endpoints. <!-- coderabbit-ai-generated:v1 -->

<!-- coderabbit-ai-generated-section:v1:370a32cbd73d23a694a90abedc1d27e50cfe5f6b13ccccd1db706ec0178019db -->

The dictionary header is rechecked after reading entries, but this does not make the snapshot atomic. The synthetic tests do not verify the game offsets or live memory.

<!-- /coderabbit-ai-generated:v1 -->

<!-- /coderabbit-ai-generated:v1 -->
