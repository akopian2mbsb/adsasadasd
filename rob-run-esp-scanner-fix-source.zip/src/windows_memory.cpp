#include "rob_run/windows_memory.hpp"

#ifdef _WIN32
#define WIN32_LEAN_AND_MEAN
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#include <limits>

namespace rob_run {
static_assert(sizeof(void*) == sizeof(Address), "a 64-bit Windows build is required");
std::optional<WindowsMemoryReader> WindowsMemoryReader::open(std::uint32_t process_id) {
    if (!process_id) return std::nullopt;
    HANDLE handle = OpenProcess(PROCESS_VM_READ | PROCESS_QUERY_LIMITED_INFORMATION, FALSE, process_id);
    if (!handle) return std::nullopt;
    return WindowsMemoryReader(handle);
}
WindowsMemoryReader::~WindowsMemoryReader() { if (handle_) CloseHandle(handle_); }
WindowsMemoryReader::WindowsMemoryReader(WindowsMemoryReader&& other) noexcept : handle_(other.handle_) {
    other.handle_ = nullptr;
}
WindowsMemoryReader& WindowsMemoryReader::operator=(WindowsMemoryReader&& other) noexcept {
    if (this != &other) {
        if (handle_) CloseHandle(handle_);
        handle_ = other.handle_;
        other.handle_ = nullptr;
    }
    return *this;
}
bool WindowsMemoryReader::read(Address address, void* destination, std::size_t size) const {
    if (!handle_ || !destination || !address || !size ||
        size - 1 > std::numeric_limits<Address>::max() - address) return false;
    SIZE_T bytes_read = 0;
    return ReadProcessMemory(handle_, reinterpret_cast<const void*>(static_cast<std::uintptr_t>(address)),
                             destination, size, &bytes_read) && bytes_read == size;
}
} // namespace rob_run
#endif
