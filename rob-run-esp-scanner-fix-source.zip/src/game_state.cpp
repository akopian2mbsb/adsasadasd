#include "rob_run/game_state.hpp"
#include "rob_run/offsets.hpp"

#include <cmath>
#include <limits>
#include <unordered_set>

namespace rob_run {
namespace {
template<class T> bool read_at(const MemoryReader& memory, Address base, Address offset, T& out) {
    constexpr Address max = std::numeric_limits<Address>::max();
    if (!base || offset > max - base || sizeof(T) - 1 > max - (base + offset)) return false;
    return memory.read(base + offset, &out, sizeof(T));
}
bool sane_vector(Vec3 v) {
    const double n = static_cast<double>(v.x)*v.x + static_cast<double>(v.y)*v.y + static_cast<double>(v.z)*v.z;
    return std::isfinite(n) && n >= 0.25 && n <= 2.25;
}
}

std::optional<BattleState> read_battle_state(const MemoryReader& memory, Address unity_entry) {
    const auto battle = follow_pointers(memory, unity_entry,
        {offsets::unity_entry_game, offsets::game_model, offsets::battle_model});
    if (!battle) return std::nullopt;
    const auto entities = follow_pointers(memory, *battle, {offsets::battle_entities});
    if (!entities) return std::nullopt;
    const auto characters = follow_pointers(memory, *entities,
        {offsets::world_entities, offsets::battle_characters});
    const auto local = follow_pointers(memory, *entities,
        {offsets::entities_player, offsets::player_server_model});
    if (!characters || !local) return std::nullopt;
    return BattleState{*battle, *entities, *characters, *local};
}

std::optional<BattleViews> read_battle_views(const MemoryReader& memory, const BattleState& state,
                                             Address battle_updater) {
    if (!state.battle_model || !state.entities_model) return std::nullopt;
    const auto updater_battle = follow_pointers(memory, battle_updater, {offsets::updater_battle});
    if (!updater_battle || *updater_battle != state.battle_model) return std::nullopt;
    const auto entities_updater = follow_pointers(memory, battle_updater, {offsets::updater_entities});
    const auto aim_updater = follow_pointers(memory, battle_updater, {offsets::updater_aim});
    if (!entities_updater || !aim_updater) return std::nullopt;
    const auto entities_link = follow_pointers(memory, *entities_updater, {offsets::entities_updater_model});
    const auto aim_link = follow_pointers(memory, *aim_updater, {offsets::aim_updater_entities});
    if (!entities_link || !aim_link || *entities_link != state.entities_model ||
        *aim_link != state.entities_model) return std::nullopt;
    const auto views = follow_pointers(memory, *entities_updater, {offsets::entities_updater_views});
    const auto brain = follow_pointers(memory, *aim_updater, {offsets::aim_updater_brain});
    if (!views || !brain) return std::nullopt;
    return BattleViews{*entities_updater, *views, *aim_updater, *brain};
}
std::optional<BattleViews> read_entry_views(const MemoryReader& memory, const BattleState& state,
                                            Address unity_entry) {
    // Game -> StartGameProcessor -> ScreenManager -> current screen -> BattleUpdater.
    const auto updater = follow_pointers(memory, unity_entry, {0x28, 0x90, 0x20, 0x50, 0x18});
    if (!updater) return std::nullopt;
    return read_battle_views(memory, state, *updater);
}

std::optional<Camera> read_camera(const MemoryReader& memory, const BattleState& state,
                                  const BattleViews& views) {
    const auto model = follow_pointers(memory, state.battle_model, {offsets::camera_model});
    if (!model || !views.camera_brain) return std::nullopt;
    Camera camera{};
    if (!read_at(memory, *model, 0x10, camera.position) ||
        !read_at(memory, *model, 0x3c, camera.forward) ||
        !read_at(memory, *model, 0x48, camera.right) ||
        !read_at(memory, *model, 0x54, camera.up) ||
        !read_at(memory, views.camera_brain, offsets::brain_fov, camera.vertical_fov_degrees))
        return std::nullopt;
    if (!std::isfinite(camera.position.x) || !std::isfinite(camera.position.y) ||
        !std::isfinite(camera.position.z) || !sane_vector(camera.forward) ||
        !sane_vector(camera.right) || !sane_vector(camera.up) ||
        !std::isfinite(camera.vertical_fov_degrees) || camera.vertical_fov_degrees <= 1 ||
        camera.vertical_fov_degrees >= 179) return std::nullopt;
    return camera;
}

std::optional<std::vector<DictionaryEntry>> read_entity_dictionary(const MemoryReader& memory,
                                                                    Address dictionary) {
    struct Entry { std::int32_t hash, next, key, padding; Address value; };
    static_assert(sizeof(Entry) == 24, "unexpected dictionary entry layout");
    constexpr std::uint32_t max_entries = 65536;
    Address entries = 0, entries_check = 0;
    std::uint32_t count = 0, count_check = 0;
    std::uint64_t capacity = 0;
    if (!read_at(memory, dictionary, 0x18, entries) || !read_at(memory, dictionary, 0x20, count) ||
        count > max_entries) return std::nullopt;
    if (!count) return std::vector<DictionaryEntry>{};
    if (!entries || !read_at(memory, entries, 0x18, capacity) || count > capacity || capacity > max_entries)
        return std::nullopt;
    const auto size = static_cast<std::size_t>(count) * sizeof(Entry);
    constexpr Address max = std::numeric_limits<Address>::max();
    if (entries > max - 0x20 || size - 1 > max - (entries + 0x20)) return std::nullopt;
    std::vector<Entry> raw(count);
    if (!memory.read(entries + 0x20, raw.data(), size) ||
        !read_at(memory, dictionary, 0x18, entries_check) ||
        !read_at(memory, dictionary, 0x20, count_check) ||
        entries_check != entries || count_check != count) return std::nullopt;
    std::unordered_set<std::int32_t> keys;
    std::vector<DictionaryEntry> result;
    for (const auto& entry : raw) {
        if (entry.hash < 0) continue;
        if (!entry.value || !keys.insert(entry.key).second) return std::nullopt;
        result.emplace_back(entry.key, entry.value);
    }
    return result;
}
} // namespace rob_run
