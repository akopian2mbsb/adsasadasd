#pragma once
#include "rob_run/windows_memory.hpp"
#include <atomic>
#include <cstdint>
#include <optional>
#include <functional>
#include <vector>

enum class ScanFailure { none, cancelled, query_denied, unreadable, name_missing, class_missing, instance_missing, limit_exceeded };
struct ScanReport {
    ScanFailure failure=ScanFailure::none;
    std::uint64_t readable_bytes=0;
    std::uint64_t failed_reads=0;
    std::size_t names=0, classes=0;
};
// Finds a managed Start.UnityEntry instance in the target's readable regions.
// Reports why the scan stopped without including target memory or addresses.
std::optional<rob_run::Address> find_unity_entry(unsigned long pid,
    const rob_run::WindowsMemoryReader& memory, const std::atomic_bool& stop,
    ScanReport* report=nullptr);

// Scans one committed region, retrying smaller pages after a bulk read fails.
using ScanCallback = std::function<bool(rob_run::Address, const unsigned char*, std::size_t)>;
bool scan_readable_region(const rob_run::MemoryReader& memory, rob_run::Address base,
    rob_run::Address end, std::size_t page_size, const std::atomic_bool& stop,
    ScanReport& report, std::vector<unsigned char>& scratch, const ScanCallback& callback);
