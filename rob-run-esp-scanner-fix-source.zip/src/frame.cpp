#include "rob_run/frame.hpp"
#include "rob_run/offsets.hpp"
#include <cmath>
#include <limits>
namespace rob_run {
std::optional<EspFrame> read_esp_frame(const MemoryReader& memory, Address entry) {
    const auto state=read_battle_state(memory,entry);
    if (!state) return std::nullopt;
    const auto views=read_entry_views(memory,*state,entry);
    if (!views) return std::nullopt;
    const auto camera=read_camera(memory,*state,*views);
    const auto characters=read_entity_dictionary(memory,state->characters_dictionary);
    if (!camera || !characters) return std::nullopt;
    EspFrame result{*camera,{}};
    for (const auto& [id, object] : *characters) {
        if (object==state->local_character || result.positions.size()>=512) continue;
        if (object>std::numeric_limits<Address>::max()-offsets::character_id-sizeof(std::int32_t)+1) continue;
        std::int32_t stored_id=0;
        if (!memory.read(object+offsets::character_id,&stored_id,sizeof(stored_id)) || id!=stored_id) continue;
        const auto transform=follow_pointers(memory,object,{offsets::character_transform});
        Vec3 p{};
        if (!transform || *transform>std::numeric_limits<Address>::max()-0x10-sizeof(p)+1 ||
            !memory.read(*transform+0x10,&p,sizeof(p))) continue;
        if (!std::isfinite(p.x) || !std::isfinite(p.y) || !std::isfinite(p.z)) continue;
        result.positions.push_back(p);
    }
    return result;
}
}
