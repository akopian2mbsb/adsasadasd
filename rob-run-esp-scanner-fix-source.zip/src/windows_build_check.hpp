#pragma once
#define WIN32_LEAN_AND_MEAN
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#include <array>
#include <cstdint>
#include <optional>
#include <string>

std::optional<std::array<std::uint8_t,32>> sha256_file(const std::wstring& path);
// Returns true only if both on-disk files match the user's 26807668 hashes.
bool matching_game_build(DWORD process_id);
