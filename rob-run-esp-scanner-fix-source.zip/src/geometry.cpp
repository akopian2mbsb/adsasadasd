#include "rob_run/geometry.hpp"

#include <cmath>
#include <limits>

namespace rob_run {
namespace {
constexpr std::int32_t max_hierarchy_size = 4096;

bool add(Address base, Address offset, Address& out) {
    if (base > std::numeric_limits<Address>::max() - offset) return false;
    out = base + offset;
    return true;
}

template <typename T>
bool read_at(const MemoryReader& memory, Address base, Address offset, T& value) {
    Address address;
    return base != 0 && add(base, offset, address) &&
           address <= std::numeric_limits<Address>::max() - (sizeof(T) - 1) &&
           memory.read(address, &value, sizeof(T));
}

template <typename T>
bool read_array(const MemoryReader& memory, Address address, std::vector<T>& values) {
    const auto size = values.size() * sizeof(T); // size is capped by max_hierarchy_size
    return address != 0 && size != 0 &&
           address <= std::numeric_limits<Address>::max() - (size - 1) &&
           memory.read(address, values.data(), size);
}

bool finite(Vec3 v) { return std::isfinite(v.x) && std::isfinite(v.y) && std::isfinite(v.z); }
Vec3 cross(Vec3 a, Vec3 b) {
    return {a.y*b.z - a.z*b.y, a.z*b.x - a.x*b.z, a.x*b.y - a.y*b.x};
}
float dot(Vec3 a, Vec3 b) { return a.x*b.x + a.y*b.y + a.z*b.z; }

std::optional<Vec3> apply_parent(const TransformTRS& trs, Vec3 v) {
    Vec3 translation{trs.position[0], trs.position[1], trs.position[2]};
    Vec3 scale{trs.scale[0], trs.scale[1], trs.scale[2]};
    Quaternion q{trs.rotation[0], trs.rotation[1], trs.rotation[2], trs.rotation[3]};
    if (!finite(translation) || !finite(scale) || !std::isfinite(q.x) ||
        !std::isfinite(q.y) || !std::isfinite(q.z) || !std::isfinite(q.w)) return std::nullopt;
    const float norm = std::sqrt(q.x*q.x + q.y*q.y + q.z*q.z + q.w*q.w);
    if (!std::isfinite(norm) || norm < 1e-6f) return std::nullopt;
    q = {q.x/norm, q.y/norm, q.z/norm, q.w/norm};
    const Vec3 scaled{scale.x*v.x, scale.y*v.y, scale.z*v.z};
    const Vec3 axis{q.x, q.y, q.z};
    const Vec3 t = cross(axis, scaled);
    const Vec3 u = cross(axis, t);
    Vec3 result{translation.x + scaled.x + 2*(q.w*t.x + u.x),
                translation.y + scaled.y + 2*(q.w*t.y + u.y),
                translation.z + scaled.z + 2*(q.w*t.z + u.z)};
    if (!finite(result)) return std::nullopt;
    return result;
}
} // namespace

std::optional<Address> follow_pointers(const MemoryReader& memory, Address start,
                                       const std::vector<Address>& offsets) {
    if (!start) return std::nullopt;
    for (Address offset : offsets) {
        Address next = 0;
        if (!read_at(memory, start, offset, next) || !next) return std::nullopt;
        start = next;
    }
    return start;
}

std::optional<Vec3> bone_world_position(const MemoryReader& memory, Address managed_transform) {
    Address native = 0, hierarchy = 0, trs_address = 0, parents_address = 0, pointers_address = 0;
    std::int32_t index = -1, count = 0;
    if (!read_at(memory, managed_transform, 0x10, native) || !native ||
        !read_at(memory, native, 0x28, hierarchy) || !hierarchy ||
        !read_at(memory, native, 0x30, index) ||
        !read_at(memory, hierarchy, 0x10, count) || count <= 0 || count > max_hierarchy_size ||
        index < 0 || index >= count ||
        !read_at(memory, hierarchy, 0x18, trs_address) ||
        !read_at(memory, hierarchy, 0x20, parents_address) ||
        !read_at(memory, hierarchy, 0x30, pointers_address)) return std::nullopt;

    Address stored_native = 0;
    if (!read_at(memory, pointers_address, static_cast<Address>(index) * sizeof(Address), stored_native) ||
        stored_native != native) return std::nullopt;

    std::vector<TransformTRS> transforms(static_cast<std::size_t>(count));
    std::vector<std::int32_t> parents(static_cast<std::size_t>(count));
    if (!read_array(memory, trs_address, transforms) || !read_array(memory, parents_address, parents))
        return std::nullopt;
    const auto& initial = transforms[static_cast<std::size_t>(index)];
    Vec3 position{initial.position[0], initial.position[1], initial.position[2]};
    if (!finite(position)) return std::nullopt;
    std::vector<bool> visited(static_cast<std::size_t>(count), false);
    visited[static_cast<std::size_t>(index)] = true;
    auto parent = parents[static_cast<std::size_t>(index)];
    while (parent != -1) {
        if (parent < 0 || parent >= count || visited[static_cast<std::size_t>(parent)]) return std::nullopt;
        visited[static_cast<std::size_t>(parent)] = true;
        auto result = apply_parent(transforms[static_cast<std::size_t>(parent)], position);
        if (!result) return std::nullopt;
        position = *result;
        parent = parents[static_cast<std::size_t>(parent)];
    }
    return position;
}

std::optional<Vec2> project(const Camera& camera, Vec3 world, float width, float height) {
    if (!finite(camera.position) || !finite(camera.right) || !finite(camera.up) ||
        !finite(camera.forward) || !finite(world) || !std::isfinite(width) ||
        !std::isfinite(height) || width <= 0 || height <= 0 ||
        !std::isfinite(camera.vertical_fov_degrees) || camera.vertical_fov_degrees <= 0 ||
        camera.vertical_fov_degrees >= 180) return std::nullopt;
    const Vec3 delta{world.x-camera.position.x, world.y-camera.position.y, world.z-camera.position.z};
    const float x = dot(delta, camera.right), y = dot(delta, camera.up), z = dot(delta, camera.forward);
    const float t = std::tan(camera.vertical_fov_degrees * 0.008726646259971648f);
    const float aspect = width / height;
    if (!std::isfinite(x) || !std::isfinite(y) || !std::isfinite(z) || z <= 0.05f ||
        !std::isfinite(t) || t <= 0 || !std::isfinite(aspect) || aspect <= 0) return std::nullopt;
    const Vec2 result{(0.5f + 0.5f*x/(z*t*aspect))*width, (0.5f - 0.5f*y/(z*t))*height};
    if (!std::isfinite(result.x) || !std::isfinite(result.y)) return std::nullopt;
    return result;
}
} // namespace rob_run
