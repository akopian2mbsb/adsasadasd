#include "rob_run/esp.hpp"

#include <utility>

namespace rob_run {
namespace {
constexpr std::array<std::pair<Joint, Joint>, 18> segments{{
    {Joint::pelvis, Joint::spine}, {Joint::spine, Joint::chest},
    {Joint::chest, Joint::neck}, {Joint::neck, Joint::head},
    {Joint::chest, Joint::left_shoulder}, {Joint::left_shoulder, Joint::left_elbow},
    {Joint::left_elbow, Joint::left_hand}, {Joint::chest, Joint::right_shoulder},
    {Joint::right_shoulder, Joint::right_elbow}, {Joint::right_elbow, Joint::right_hand},
    {Joint::pelvis, Joint::left_hip}, {Joint::left_hip, Joint::left_knee},
    {Joint::left_knee, Joint::left_ankle}, {Joint::left_ankle, Joint::left_foot},
    {Joint::pelvis, Joint::right_hip}, {Joint::right_hip, Joint::right_knee},
    {Joint::right_knee, Joint::right_ankle}, {Joint::right_ankle, Joint::right_foot}
}};
}
Skeleton read_skeleton(const MemoryReader& memory, const JointAddresses& joints) {
    Skeleton result{};
    for (std::size_t i = 0; i < joints.size(); ++i)
        if (joints[i]) result[i] = bone_world_position(memory, *joints[i]);
    return result;
}
std::vector<EspLine> skeleton_lines(const Skeleton& skeleton, const Camera& camera,
                                    float width, float height) {
    std::array<std::optional<Vec2>, joint_count> projected{};
    for (std::size_t i = 0; i < skeleton.size(); ++i)
        if (skeleton[i]) projected[i] = project(camera, *skeleton[i], width, height);
    std::vector<EspLine> lines;
    lines.reserve(segments.size());
    for (const auto& [a, b] : segments) {
        const auto& first = projected[static_cast<std::size_t>(a)];
        const auto& second = projected[static_cast<std::size_t>(b)];
        if (first && second) lines.push_back({*first, *second});
    }
    return lines;
}
} // namespace rob_run
