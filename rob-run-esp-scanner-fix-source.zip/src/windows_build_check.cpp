#include "windows_build_check.hpp"
#include <wincrypt.h>

std::optional<std::array<std::uint8_t,32>> sha256_file(const std::wstring& path) {
    HANDLE file=CreateFileW(path.c_str(),GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE|FILE_SHARE_DELETE,
                            nullptr,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,nullptr);
    if (file==INVALID_HANDLE_VALUE) return std::nullopt;
    struct CloseFile { HANDLE f; ~CloseFile() { CloseHandle(f); } } close{file};
    HCRYPTPROV provider=0;
    if (!CryptAcquireContextW(&provider,nullptr,nullptr,PROV_RSA_AES,CRYPT_VERIFYCONTEXT)) return std::nullopt;
    struct CloseProvider { HCRYPTPROV p; ~CloseProvider() { CryptReleaseContext(p,0); } } release{provider};
    HCRYPTHASH hash=0;
    if (!CryptCreateHash(provider,CALG_SHA_256,0,0,&hash)) return std::nullopt;
    struct CloseHash { HCRYPTHASH h; ~CloseHash() { CryptDestroyHash(h); } } destroy{hash};
    std::array<BYTE,65536> buffer{};
    for (;;) {
        DWORD count=0;
        if (!ReadFile(file,buffer.data(),static_cast<DWORD>(buffer.size()),&count,nullptr)) return std::nullopt;
        if (!count) break;
        if (!CryptHashData(hash,buffer.data(),count,0)) return std::nullopt;
    }
    std::array<std::uint8_t,32> result{}; DWORD size=static_cast<DWORD>(result.size());
    if (!CryptGetHashParam(hash,HP_HASHVAL,result.data(),&size,0) || size!=result.size()) return std::nullopt;
    return result;
}

bool matching_game_build(DWORD pid) {
    constexpr std::array<std::uint8_t,32> assembly={0xE4,0xB1,0x91,0xF5,0xB1,0x5F,0x6A,0x00,0x54,0x54,0xDA,0xBD,0xB5,0x0E,0x13,0x10,0xDE,0xD9,0x8F,0x13,0x5A,0xFE,0x6F,0x17,0x0F,0xC3,0x12,0x2F,0x0B,0x4E,0xD0,0x62};
    constexpr std::array<std::uint8_t,32> metadata={0x96,0xA8,0x60,0x61,0x8A,0xA0,0xA6,0xC5,0xDF,0x88,0x45,0x0D,0x29,0x06,0x31,0x0E,0x52,0xB8,0xF7,0x98,0x0D,0x21,0x06,0x75,0xA6,0x43,0xFD,0x42,0x94,0x51,0xA6,0x2E};
    HANDLE process=OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION,FALSE,pid);
    if (!process) return false;
    struct CloseProcess { HANDLE p; ~CloseProcess() { CloseHandle(p); } } close{process};
    std::wstring path(32768,L'\0'); DWORD size=static_cast<DWORD>(path.size());
    if (!QueryFullProcessImageNameW(process,0,path.data(),&size)) return false;
    path.resize(size);
    const auto slash=path.find_last_of(L"\\/");
    if (slash==std::wstring::npos) return false;
    path.resize(slash+1);
    const auto a=sha256_file(path+L"GameAssembly.dll");
    const auto m=sha256_file(path+L"ROB RUN_Data\\il2cpp_data\\Metadata\\global-metadata.dat");
    return a && m && *a==assembly && *m==metadata;
}
