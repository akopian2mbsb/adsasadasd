#define WIN32_LEAN_AND_MEAN
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#include <tlhelp32.h>
#include "rob_run/game_state.hpp"
#include "rob_run/frame.hpp"
#include "rob_run/offsets.hpp"
#include "rob_run/windows_memory.hpp"
#include "windows_scanner.hpp"
#include "windows_build_check.hpp"
#include <atomic>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <cwchar>
#include <mutex>
#include <optional>
#include <string>
#include <thread>
#include <vector>

namespace {
using namespace rob_run;
struct Snapshot { Camera camera{}; std::vector<Vec3> positions; bool valid=false; };
std::atomic_bool stopping{false}, enabled{true}, rescan{false};
std::mutex shared_mutex;
Snapshot snapshot;
std::wstring status=L"Waiting for ROB RUN...";
DWORD game_pid=0;
HWND controls=nullptr, overlay=nullptr, status_label=nullptr, toggle_button=nullptr;
HBRUSH background_brush=nullptr;
HFONT body_font=nullptr, title_font=nullptr;
bool smoke=false;

void publish(const wchar_t* text, DWORD pid, Snapshot value={}) {
    std::lock_guard<std::mutex> lock(shared_mutex);
    status=text; game_pid=pid; snapshot=std::move(value);
}
DWORD find_game() {
    HANDLE list=CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS,0);
    if (list==INVALID_HANDLE_VALUE) return 0;
    PROCESSENTRY32W item{}; item.dwSize=sizeof(item);
    DWORD result=0;
    if (Process32FirstW(list,&item)) do {
        if (_wcsicmp(item.szExeFile,L"ROB RUN.exe")==0) { result=item.th32ProcessID; break; }
    } while (Process32NextW(list,&item));
    CloseHandle(list); return result;
}
BOOL CALLBACK find_window(HWND w, LPARAM param) {
    auto* pair=reinterpret_cast<std::pair<DWORD,HWND>*>(param);
    DWORD pid=0; GetWindowThreadProcessId(w,&pid);
    if (pid==pair->first && IsWindowVisible(w) && !GetWindow(w,GW_OWNER)) {
        RECT rect{}; if (GetClientRect(w,&rect) && rect.right>100 && rect.bottom>100) {pair->second=w; return FALSE;}
    }
    return TRUE;
}
HWND game_window(DWORD pid) {
    std::pair<DWORD,HWND> pair{pid,nullptr}; EnumWindows(find_window,reinterpret_cast<LPARAM>(&pair)); return pair.second;
}

std::optional<Snapshot> collect(const MemoryReader& memory, Address entry) {
    auto frame=read_esp_frame(memory,entry);
    if (!frame) return std::nullopt;
    return Snapshot{frame->camera,std::move(frame->positions),true};
}
const wchar_t* scan_message(ScanFailure failure) {
    switch (failure) {
    case ScanFailure::query_denied: return L"Cannot query game memory regions.";
    case ScanFailure::unreadable: return L"No readable game memory was found.";
    case ScanFailure::name_missing: return L"UnityEntry name not found in readable memory.";
    case ScanFailure::class_missing: return L"UnityEntry class not found. Check game build.";
    case ScanFailure::instance_missing: return L"UnityEntry instance not found. Join a match.";
    case ScanFailure::limit_exceeded: return L"Too many scan candidates. Rescan in a match.";
    case ScanFailure::cancelled: return L"Scan cancelled.";
    default: return L"UnityEntry scan failed.";
    }
}
void worker() {
    while (!stopping.load()) {
        const DWORD pid=find_game();
        if (!pid) { publish(L"Start ROB RUN, then join a match.",0); std::this_thread::sleep_for(std::chrono::seconds(1)); continue; }
        auto memory=WindowsMemoryReader::open(pid);
        if (!memory) { publish(L"Cannot read game process. Check process access.",pid); std::this_thread::sleep_for(std::chrono::seconds(2)); continue; }
        publish(L"Checking game files for build 26807668...",pid);
        if (!matching_game_build(pid)) {
            publish(L"Game files unavailable or do not match build 26807668.",pid);
            std::this_thread::sleep_for(std::chrono::seconds(5)); continue;
        }
        Address entry=0;
        auto check_pid=std::chrono::steady_clock::now();
        auto retry=std::chrono::steady_clock::now();
        while (!stopping.load()) {
            if (std::chrono::steady_clock::now()>=check_pid) {
                if (find_game()!=pid) break;
                check_pid=std::chrono::steady_clock::now()+std::chrono::seconds(1);
            }
            if (!entry || rescan.exchange(false)) {
                rescan.store(false);
                publish(L"Scanning game memory for UnityEntry...",pid);
                ScanReport report;
                auto found=find_unity_entry(pid,*memory,stopping,&report);
                if (!found) {
                    if (stopping.load()) break;
                    publish(scan_message(report.failure),pid);
                    // Keep the diagnosis visible and avoid continuously rescanning large regions.
                    for (int i=0; i<50 && !stopping.load(); ++i) {
                        if (rescan.exchange(false) || find_game()!=pid) break;
                        std::this_thread::sleep_for(std::chrono::milliseconds(200));
                    }
                    if (find_game()!=pid) break;
                    continue;
                }
                entry=*found; retry=std::chrono::steady_clock::now()+std::chrono::seconds(20);
            }
            auto current=collect(*memory,entry);
            if (!current) {
                publish(L"Waiting for match data or compatible offsets...",pid);
                if (std::chrono::steady_clock::now()>=retry) { entry=0; }
            } else {
                publish(L"Connected. Boxes use estimated player height.",pid,std::move(*current));
                retry=std::chrono::steady_clock::now()+std::chrono::seconds(20);
            }
            std::this_thread::sleep_for(std::chrono::milliseconds(100));
        }
        if (!stopping.load()) std::this_thread::sleep_for(std::chrono::seconds(2));
    }
}

void paint_overlay(HWND w) {
    PAINTSTRUCT ps{}; HDC screen=BeginPaint(w,&ps); RECT rect{}; GetClientRect(w,&rect);
    const int width=rect.right, height=rect.bottom;
    if (width>0 && height>0) {
        HDC dc=CreateCompatibleDC(screen); HBITMAP bitmap=CreateCompatibleBitmap(screen,width,height);
        auto old_bitmap=SelectObject(dc,bitmap);
        FillRect(dc,&rect,static_cast<HBRUSH>(GetStockObject(BLACK_BRUSH)));
        Snapshot frame;
        { std::lock_guard<std::mutex> lock(shared_mutex); frame=snapshot; }
        if (enabled.load() && frame.valid) {
            HPEN pen=CreatePen(PS_SOLID,2,RGB(78,233,201)); auto old_pen=SelectObject(dc,pen);
            auto old_brush=SelectObject(dc,GetStockObject(NULL_BRUSH));
            SetBkMode(dc,TRANSPARENT); SetTextColor(dc,RGB(220,255,249));
            for (const auto& p : frame.positions) {
                auto feet=project(frame.camera,p,static_cast<float>(width),static_cast<float>(height));
                auto head=project(frame.camera,{p.x,p.y+1.8f,p.z},static_cast<float>(width),static_cast<float>(height));
                if (!feet || !head) continue;
                const float h=feet->y-head->y;
                if (!(h>4 && h<height*2.0f) || head->x < -width || head->x > width*2.0f ||
                    head->y < -height*2.0f || head->y > height*2.0f) continue;
                const int x=static_cast<int>(head->x), top=static_cast<int>(head->y), bottom=static_cast<int>(feet->y);
                const int half=static_cast<int>(h*0.25f);
                Rectangle(dc,x-half,top,x+half,bottom);
                TextOutW(dc,x-half,top-16,L"PLAYER",6);
            }
            SelectObject(dc,old_brush); SelectObject(dc,old_pen); DeleteObject(pen);
        }
        BitBlt(screen,0,0,width,height,dc,0,0,SRCCOPY);
        SelectObject(dc,old_bitmap); DeleteObject(bitmap); DeleteDC(dc);
    }
    EndPaint(w,&ps);
}
LRESULT CALLBACK overlay_proc(HWND w,UINT msg,WPARAM wp,LPARAM lp) {
    if (msg==WM_PAINT) { paint_overlay(w); return 0; }
    if (msg==WM_ERASEBKGND) return 1;
    return DefWindowProcW(w,msg,wp,lp);
}
void update_overlay() {
    DWORD pid; std::wstring text;
    { std::lock_guard<std::mutex> lock(shared_mutex); pid=game_pid; text=status; }
    SetWindowTextW(status_label,text.c_str());
    HWND game=smoke ? controls : game_window(pid);
    if (!game || IsIconic(game) || (GetForegroundWindow()!=game && GetForegroundWindow()!=controls)) {
        ShowWindow(overlay,SW_HIDE); return;
    }
    RECT r{}; POINT origin{0,0};
    if (!GetClientRect(game,&r) || !ClientToScreen(game,&origin) || r.right<=0 || r.bottom<=0) return;
    SetWindowPos(overlay,HWND_TOPMOST,origin.x,origin.y,r.right,r.bottom,SWP_NOACTIVATE|SWP_SHOWWINDOW);
    InvalidateRect(overlay,nullptr,FALSE);
}
LRESULT CALLBACK controls_proc(HWND w,UINT msg,WPARAM wp,LPARAM lp) {
    switch(msg) {
    case WM_CREATE: {
        background_brush=CreateSolidBrush(RGB(19,25,31));
        body_font=CreateFontW(-16,0,0,0,FW_NORMAL,FALSE,FALSE,FALSE,DEFAULT_CHARSET,0,0,CLEARTYPE_QUALITY,0,L"Segoe UI");
        title_font=CreateFontW(-21,0,0,0,FW_SEMIBOLD,FALSE,FALSE,FALSE,DEFAULT_CHARSET,0,0,CLEARTYPE_QUALITY,0,L"Segoe UI");
        HWND title=CreateWindowW(L"STATIC",L"ROB RUN   /   EXTERNAL ESP",WS_CHILD|WS_VISIBLE,20,17,390,28,w,nullptr,nullptr,nullptr);
        status_label=CreateWindowW(L"STATIC",L"Starting...",WS_CHILD|WS_VISIBLE,20,54,390,40,w,nullptr,nullptr,nullptr);
        toggle_button=CreateWindowW(L"BUTTON",L"ESP: ON",WS_CHILD|WS_VISIBLE|BS_OWNERDRAW,20,108,130,36,w,reinterpret_cast<HMENU>(1),nullptr,nullptr);
        HWND rescan_button=CreateWindowW(L"BUTTON",L"Rescan",WS_CHILD|WS_VISIBLE|BS_OWNERDRAW,160,108,120,36,w,reinterpret_cast<HMENU>(2),nullptr,nullptr);
        HWND hint=CreateWindowW(L"STATIC",L"Boxes use estimated height. Close to exit.",WS_CHILD|WS_VISIBLE,20,160,390,30,w,nullptr,nullptr,nullptr);
        SendMessageW(title,WM_SETFONT,reinterpret_cast<WPARAM>(title_font),TRUE);
        for (HWND child : {status_label,toggle_button,rescan_button,hint}) SendMessageW(child,WM_SETFONT,reinterpret_cast<WPARAM>(body_font),TRUE);
        SetTimer(w,1,100,nullptr); if (smoke) SetTimer(w,2,1800,nullptr); return 0;
    }
    case WM_CTLCOLORSTATIC: {
        HDC dc=reinterpret_cast<HDC>(wp); SetTextColor(dc,RGB(224,238,238)); SetBkMode(dc,TRANSPARENT);
        return reinterpret_cast<LRESULT>(background_brush);
    }
    case WM_ERASEBKGND: {
        RECT r{}; GetClientRect(w,&r); FillRect(reinterpret_cast<HDC>(wp),&r,background_brush); return 1;
    }
    case WM_DRAWITEM: {
        const auto* item=reinterpret_cast<const DRAWITEMSTRUCT*>(lp);
        if (!item || item->CtlType!=ODT_BUTTON) return FALSE;
        const bool active=item->CtlID==1 && enabled.load();
        HBRUSH brush=CreateSolidBrush(active ? RGB(43,142,124) : RGB(49,61,70));
        FillRect(item->hDC,&item->rcItem,brush); DeleteObject(brush);
        wchar_t label[40]{}; GetWindowTextW(item->hwndItem,label,40);
        auto old=SelectObject(item->hDC,body_font); SetTextColor(item->hDC,RGB(246,255,253)); SetBkMode(item->hDC,TRANSPARENT);
        RECT area=item->rcItem; DrawTextW(item->hDC,label,-1,&area,DT_CENTER|DT_VCENTER|DT_SINGLELINE);
        SelectObject(item->hDC,old); return TRUE;
    }
    case WM_COMMAND:
        if (LOWORD(wp)==1) { const bool next=!enabled.load(); enabled.store(next); SetWindowTextW(toggle_button,next?L"ESP: ON":L"ESP: OFF"); }
        if (LOWORD(wp)==2) rescan.store(true);
        return 0;
    case WM_TIMER:
        if (wp==2) { DestroyWindow(w); return 0; }
        update_overlay(); return 0;
    case WM_DESTROY:
        stopping.store(true); if (background_brush) DeleteObject(background_brush);
        if (body_font) DeleteObject(body_font);
        if (title_font) DeleteObject(title_font);
        PostQuitMessage(0); return 0;
    }
    return DefWindowProcW(w,msg,wp,lp);
}
}
int WINAPI wWinMain(HINSTANCE instance,HINSTANCE,LPWSTR command,int) {
    smoke=command && std::wcscmp(command,L"--smoke")==0;
    SetProcessDPIAware();
    WNDCLASSW oc{}; oc.lpfnWndProc=overlay_proc; oc.hInstance=instance; oc.lpszClassName=L"RRExternalOverlay";
    WNDCLASSW cc{}; cc.lpfnWndProc=controls_proc; cc.hInstance=instance; cc.lpszClassName=L"RRExternalControls";
    cc.hbrBackground=reinterpret_cast<HBRUSH>(COLOR_WINDOW+1); cc.hCursor=LoadCursor(nullptr,IDC_ARROW);
    if (!RegisterClassW(&oc) || !RegisterClassW(&cc)) return 1;
    overlay=CreateWindowExW(WS_EX_LAYERED|WS_EX_TRANSPARENT|WS_EX_TOOLWINDOW|WS_EX_NOACTIVATE,
        oc.lpszClassName,L"",WS_POPUP,0,0,1,1,nullptr,nullptr,instance,nullptr);
    if (!overlay || !SetLayeredWindowAttributes(overlay,RGB(0,0,0),0,LWA_COLORKEY)) return 2;
    controls=CreateWindowW(cc.lpszClassName,L"ROB RUN External ESP",WS_OVERLAPPED|WS_CAPTION|WS_SYSMENU|WS_MINIMIZEBOX,
        CW_USEDEFAULT,CW_USEDEFAULT,440,245,nullptr,nullptr,instance,nullptr);
    if (!controls) { DestroyWindow(overlay); return 3; }
    ShowWindow(controls,SW_SHOW); UpdateWindow(controls);
    std::thread reader;
    if (smoke) {
        Snapshot demo; demo.valid=true; demo.camera={{0,0,0},{1,0,0},{0,1,0},{0,0,1},90}; demo.positions.push_back({0,-0.9f,4});
        publish(L"Test display",GetCurrentProcessId(),std::move(demo));
    } else reader=std::thread(worker);
    MSG msg{}; int code=0;
    while ((code=GetMessageW(&msg,nullptr,0,0))>0) { TranslateMessage(&msg); DispatchMessageW(&msg); }
    stopping.store(true); if (reader.joinable()) reader.join();
    DestroyWindow(overlay);
    return code<0 ? 4 : 0;
}
