#include "windows_scanner.hpp"
#include "rob_run/geometry.hpp"
#define WIN32_LEAN_AND_MEAN
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#include <algorithm>
#include <cstring>
#include <limits>
#include <unordered_set>
#include <vector>

namespace {
using rob_run::Address;
constexpr std::size_t chunk_size = 1u << 20;
constexpr std::size_t max_candidates = 65536;

bool ascii_equals(const rob_run::MemoryReader& reader, Address addr, const char* text) {
    if (!addr) return false;
    for (std::size_t i=0; text[i]; ++i) {
        char c = 0;
        if (addr > std::numeric_limits<Address>::max() - i ||
            !reader.read(addr + i, &c, 1) || c != text[i]) return false;
    }
    char end = 1;
    const auto n = std::strlen(text);
    return addr <= std::numeric_limits<Address>::max() - n && reader.read(addr+n, &end, 1) && end == 0;
}

bool object_is(const rob_run::MemoryReader& reader, Address object, const char* type, const char* ns_name) {
    Address klass = 0, name = 0, ns = 0;
    return object && reader.read(object, &klass, sizeof(klass)) && klass &&
           klass <= std::numeric_limits<Address>::max() - 0x1f &&
           reader.read(klass+0x10, &name, sizeof(name)) && reader.read(klass+0x18, &ns, sizeof(ns)) &&
           ascii_equals(reader, name, type) && ascii_equals(reader, ns, ns_name);
}

template <class Fn>
void scan(HANDLE proc, const rob_run::WindowsMemoryReader& reader, const std::atomic_bool& stop,
          bool private_only, ScanReport& report, Fn callback) {
    Address at = 0;
    SYSTEM_INFO sys{}; GetSystemInfo(&sys);
    const auto page_size = std::min<std::size_t>(chunk_size, sys.dwPageSize ? sys.dwPageSize : 4096);
    std::vector<unsigned char> data(chunk_size + 16);
    while (!stop.load()) {
        MEMORY_BASIC_INFORMATION info{};
        if (!VirtualQueryEx(proc, reinterpret_cast<void*>(static_cast<std::uintptr_t>(at)), &info, sizeof(info))) break;
        const Address base = reinterpret_cast<std::uintptr_t>(info.BaseAddress);
        const Address length = info.RegionSize;
        if (length == 0 || base > std::numeric_limits<Address>::max() - length) break;
        const Address end = base + length;
        if (end <= at) break;
        if (info.State == MEM_COMMIT && !(info.Protect & (PAGE_GUARD | PAGE_NOACCESS)) &&
            (!private_only || info.Type == MEM_PRIVATE)) {
            if (scan_readable_region(reader,base,end,page_size,stop,report,data,callback)) return;
        }
        at = end;
    }
}
}

bool scan_readable_region(const rob_run::MemoryReader& reader, Address base, Address end,
    std::size_t page_size, const std::atomic_bool& stop, ScanReport& report,
    std::vector<unsigned char>& data, const ScanCallback& callback) {
    if (!page_size || page_size > chunk_size || base >= end) return false;
    data.resize(chunk_size+16);
    for (Address pos=base; pos<end && !stop.load();) {
        const auto remaining=end-pos;
        const auto size=static_cast<std::size_t>(std::min<Address>(chunk_size+16,remaining));
        if (reader.read(pos,data.data(),size)) {
            report.readable_bytes+=size;
            if (callback(pos,data.data(),size)) return true;
        } else {
            ++report.failed_reads;
            const auto span=static_cast<std::size_t>(std::min<Address>(chunk_size,remaining));
            for (std::size_t offset=0; offset<span && !stop.load(); offset+=page_size) {
                const auto piece=static_cast<std::size_t>(std::min<Address>(page_size+16,end-(pos+offset)));
                auto usable=piece;
                if (!reader.read(pos+offset,data.data(),piece)) {
                    ++report.failed_reads;
                    usable=std::min(page_size,span-offset);
                    if (!reader.read(pos+offset,data.data(),usable)) { ++report.failed_reads; continue; }
                    // Preserve a boundary-spanning match when the next bytes are separately readable.
                    const auto extra=static_cast<std::size_t>(std::min<Address>(16,end-(pos+offset+usable)));
                    if (extra && reader.read(pos+offset+usable,data.data()+usable,extra)) usable+=extra;
                }
                report.readable_bytes+=usable;
                if (callback(pos+offset,data.data(),usable)) return true;
            }
        }
        const auto step=std::min<Address>(chunk_size,remaining);
        if (!step) break;
        pos+=step;
    }
    return false;
}

std::optional<rob_run::Address> find_unity_entry(unsigned long pid,
    const rob_run::WindowsMemoryReader& memory, const std::atomic_bool& stop, ScanReport* output) {
    ScanReport local{};
    ScanReport& report = output ? *output : local;
    report = {};
    if (stop.load()) { report.failure=ScanFailure::cancelled; return std::nullopt; }
    HANDLE proc = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, pid);
    if (!proc) { report.failure=ScanFailure::query_denied; return std::nullopt; }
    struct Close { HANDLE h; ~Close() { CloseHandle(h); } } close{proc};
    constexpr char needle[] = "UnityEntry";
    bool limit_hit=false;
    std::unordered_set<Address> names;
    scan(proc, memory, stop, false, report, [&](Address base, const unsigned char* bytes, std::size_t n) {
        for (std::size_t i=0; i+sizeof(needle)<=n; ++i) {
            if (std::memcmp(bytes+i, needle, sizeof(needle)) != 0) continue;
            if (names.size()>=max_candidates && !names.count(base+i)) { limit_hit=true; return true; }
            names.insert(base+i);
        }
        return false;
    });
    report.names=names.size();
    if (stop.load()) { report.failure=ScanFailure::cancelled; return std::nullopt; }
    if (limit_hit) { report.failure=ScanFailure::limit_exceeded; return std::nullopt; }
    if (names.empty()) { report.failure=report.readable_bytes ? ScanFailure::name_missing : ScanFailure::unreadable; return std::nullopt; }
    std::unordered_set<Address> classes;
    scan(proc, memory, stop, false, report, [&](Address base, const unsigned char* bytes, std::size_t n) {
        const auto start = static_cast<std::size_t>((8 - (base & 7)) & 7);
        for (std::size_t i=start; i+8<=n; i+=8) {
            Address ptr=0; std::memcpy(&ptr, bytes+i, 8);
            const Address ref=base+i;
            if (!names.count(ptr) || ref < 0x10) continue;
            const Address klass=ref-0x10;
            Address ns=0;
            if (klass <= std::numeric_limits<Address>::max()-0x1f &&
                memory.read(klass+0x18, &ns, sizeof(ns)) && ascii_equals(memory, ns, "Start")) {
                if (classes.size()>=max_candidates && !classes.count(klass)) { limit_hit=true; return true; }
                classes.insert(klass);
            }
        }
        return false;
    });
    report.classes=classes.size();
    if (stop.load()) { report.failure=ScanFailure::cancelled; return std::nullopt; }
    if (limit_hit) { report.failure=ScanFailure::limit_exceeded; return std::nullopt; }
    if (classes.empty()) { report.failure=ScanFailure::class_missing; return std::nullopt; }
    std::optional<Address> found;
    scan(proc, memory, stop, true, report, [&](Address base, const unsigned char* bytes, std::size_t n) {
        const auto start = static_cast<std::size_t>((8 - (base & 7)) & 7);
        for (std::size_t i=start; i+8<=n; i+=8) {
            Address ptr=0; std::memcpy(&ptr, bytes+i, 8);
            if (!classes.count(ptr)) continue;
            const Address object=base+i;
            const auto game=rob_run::follow_pointers(memory, object, {0x28});
            if (!game || !object_is(memory, *game, "Game", "Game")) continue;
            const auto model=rob_run::follow_pointers(memory, *game, {0xd0});
            if (model && object_is(memory, *model, "GameModel", "Game")) { found=object; return true; }
        }
        return false;
    });
    if (stop.load()) report.failure=ScanFailure::cancelled;
    else if (!found) report.failure=ScanFailure::instance_missing;
    return found;
}
