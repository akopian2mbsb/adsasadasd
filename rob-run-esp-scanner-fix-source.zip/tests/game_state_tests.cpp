#include "rob_run/game_state.hpp"

#include <cstdint>
#include <iostream>
#include <map>

using namespace rob_run;
namespace {
class Fixture : public MemoryReader {
public:
    std::map<Address, unsigned char> bytes;
    void pointer(Address address, Address value) {
        const auto* p = reinterpret_cast<const unsigned char*>(&value);
        for (std::size_t i = 0; i < sizeof(value); ++i) bytes[address + i] = p[i];
    }
    bool read(Address address, void* destination, std::size_t size) const override {
        auto* p = static_cast<unsigned char*>(destination);
        for (std::size_t i = 0; i < size; ++i) {
            const auto it = bytes.find(address + i);
            if (it == bytes.end()) return false;
            p[i] = it->second;
        }
        return true;
    }
};
int failed = 0;
void check(bool ok, const char* message) {
    if (!ok) { ++failed; std::cerr << "FAIL: " << message << '\n'; }
}
Fixture make_fixture() {
    Fixture m;
    m.pointer(0x1028, 0x2000); m.pointer(0x20d0, 0x3000);
    m.pointer(0x3010, 0x4000); m.pointer(0x4090, 0x5000);
    m.pointer(0x5060, 0x6000); m.pointer(0x6018, 0x7000);
    m.pointer(0x50d0, 0x8000); m.pointer(0x8020, 0x9000);
    m.pointer(0xa0e0, 0x4000); m.pointer(0xa090, 0xb000); m.pointer(0xa1c0, 0xc000);
    m.pointer(0xb018, 0x5000); m.pointer(0xb110, 0xd000);
    m.pointer(0xc030, 0x5000); m.pointer(0xc048, 0xe000);
    return m;
}
}
int main() {
    auto m = make_fixture();
    auto state = read_battle_state(m, 0x1000);
    check(state && state->battle_model == 0x4000 && state->entities_model == 0x5000 &&
          state->characters_dictionary == 0x7000 && state->local_character == 0x9000,
          "resolve active session and local character");
    if (state) {
        auto views = read_battle_views(m, *state, 0xa000);
        check(views && views->entities_updater == 0xb000 && views->character_views_dictionary == 0xd000 &&
              views->aim_updater == 0xc000 && views->camera_brain == 0xe000, "resolve matching updaters");
        m.pointer(0xa0e0, 0x1234);
        check(!read_battle_views(m, *state, 0xa000), "reject updater from another battle");
        m = make_fixture(); m.pointer(0xc030, 0x1234);
        check(!read_battle_views(m, *state, 0xa000), "reject aim updater from another entity model");
        m = make_fixture(); m.pointer(0xb018, 0x1234);
        check(!read_battle_views(m, *state, 0xa000), "reject views updater from another entity model");
        m = make_fixture(); m.pointer(0xc048, 0);
        check(!read_battle_views(m, *state, 0xa000), "reject missing camera");
    }
    m = make_fixture(); m.pointer(0x3010, 0);
    check(!read_battle_state(m, 0x1000), "reject inactive session");
    m = make_fixture(); m.pointer(0x8020, 0);
    check(!read_battle_state(m, 0x1000), "reject missing local character");
    m = make_fixture(); m.bytes.erase(0x6018);
    check(!read_battle_state(m, 0x1000), "reject unreadable dictionary pointer");
    if (!failed) std::cout << "All game state checks passed\n";
    return failed ? 1 : 0;
}
