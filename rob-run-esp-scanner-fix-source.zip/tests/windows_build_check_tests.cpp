#include "windows_build_check.hpp"
#include <cstdio>
int main() {
    wchar_t dir[MAX_PATH]{}; wchar_t path[MAX_PATH]{};
    if (!GetTempPathW(MAX_PATH,dir) || !GetTempFileNameW(dir,L"rr",0,path)) return 1;
    HANDLE file=CreateFileW(path,GENERIC_WRITE,0,nullptr,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,nullptr);
    if (file==INVALID_HANDLE_VALUE) return 2;
    DWORD written=0; bool ok=WriteFile(file,"abc",3,&written,nullptr) && written==3; CloseHandle(file);
    const std::array<std::uint8_t,32> expected={0xba,0x78,0x16,0xbf,0x8f,0x01,0xcf,0xea,0x41,0x41,0x40,0xde,0x5d,0xae,0x22,0x23,0xb0,0x03,0x61,0xa3,0x96,0x17,0x7a,0x9c,0xb4,0x10,0xff,0x61,0xf2,0x00,0x15,0xad};
    auto result=sha256_file(path); DeleteFileW(path);
    if (!ok || !result || *result!=expected || sha256_file(path)) return 3;
    std::puts("Windows SHA-256 fixture passed"); return 0;
}
