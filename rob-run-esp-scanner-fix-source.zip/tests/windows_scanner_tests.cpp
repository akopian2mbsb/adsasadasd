#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include "windows_scanner.hpp"
#include <atomic>
#include <cstdio>
#include <cstring>
#include <cstdint>
#include <vector>
#include <algorithm>

class PartialMemory final : public rob_run::MemoryReader {
public:
    std::vector<unsigned char> data=std::vector<unsigned char>(4*4096);
    bool read(rob_run::Address address, void* destination, std::size_t size) const override {
        constexpr rob_run::Address base=0x100000;
        if (address<base || size>4096 || address-base>data.size() || size>data.size()-(address-base)) return false;
        const auto offset=static_cast<std::size_t>(address-base);
        if (offset<2*4096 && offset+size>4096) return false; // inaccessible second page
        std::memcpy(destination,data.data()+offset,size); return true;
    }
};
int main() {
    using rob_run::Address;
    auto mem=rob_run::WindowsMemoryReader::open(GetCurrentProcessId());
    if (!mem) return 1;
    // Put a minimal managed object graph in private memory, as in the SDK layout.
    auto* block=static_cast<unsigned char*>(VirtualAlloc(nullptr,65536,MEM_COMMIT|MEM_RESERVE,PAGE_READWRITE));
    if (!block) return 2;
    auto addr=[&](std::size_t offset) { return static_cast<Address>(reinterpret_cast<std::uintptr_t>(block+offset)); };
    auto put=[&](std::size_t offset,Address value) { std::memcpy(block+offset,&value,sizeof(value)); };
    // Decoy names can precede the real class name in game memory.
    for (std::size_t i=0; i<256; ++i) std::memcpy(block+i*16,"UnityEntry",11);
    std::memcpy(block+0x3000,"UnityEntry",11); std::memcpy(block+0x3020,"Start",6);
    std::memcpy(block+0x3040,"Game",5); std::memcpy(block+0x3060,"GameModel",10);
    put(0x3210,addr(0x3000)); put(0x3218,addr(0x3020));
    put(0x3250,addr(0x3040)); put(0x3258,addr(0x3040));
    put(0x3290,addr(0x3060)); put(0x3298,addr(0x3040));
    put(0x3300,addr(0x3200)); put(0x3328,addr(0x3400));
    put(0x3400,addr(0x3240)); put(0x34d0,addr(0x3500)); put(0x3500,addr(0x3280));
    std::atomic_bool stop{false};
    ScanReport report;
    auto found=find_unity_entry(GetCurrentProcessId(),*mem,stop,&report);
    if (!found || *found!=addr(0x3300) || report.failure!=ScanFailure::none || report.names<257) { VirtualFree(block,0,MEM_RELEASE); return 3; }
    put(0x34d0,0);
    if (find_unity_entry(GetCurrentProcessId(),*mem,stop,&report) || report.failure!=ScanFailure::instance_missing) { VirtualFree(block,0,MEM_RELEASE); return 6; }
    if (find_unity_entry(0,*mem,stop,&report) || report.failure!=ScanFailure::query_denied) { VirtualFree(block,0,MEM_RELEASE); return 7; }
    stop.store(true);
    if (find_unity_entry(GetCurrentProcessId(),*mem,stop,&report) || report.failure!=ScanFailure::cancelled) { VirtualFree(block,0,MEM_RELEASE); return 4; }
    VirtualFree(block,0,MEM_RELEASE);
    PartialMemory partial;
    std::memcpy(partial.data.data()+3*4096-5,"UnityEntry",11);
    std::vector<unsigned char> scratch; stop.store(false); report={};
    bool located=scan_readable_region(partial,0x100000,0x104000,4096,stop,report,scratch,
        [](Address, const unsigned char* data,std::size_t size) {
            constexpr char target[]="UnityEntry";
            return std::search(data,data+size,target,target+sizeof(target))!=data+size;
        });
    if (!located || !report.failed_reads || !report.readable_bytes) return 5;
    std::puts("UnityEntry scanner fixture passed");
    return 0;
}
