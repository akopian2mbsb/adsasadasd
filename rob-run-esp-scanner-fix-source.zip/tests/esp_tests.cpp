#include "rob_run/esp.hpp"

#include <cmath>
#include <cstdint>
#include <iostream>
#include <map>

using namespace rob_run;
namespace {
class Fixture final : public MemoryReader {
public:
    std::map<Address, unsigned char> bytes;
    template<class T> void put(Address address, const T& value) {
        auto p = reinterpret_cast<const unsigned char*>(&value);
        for (std::size_t i = 0; i < sizeof(T); ++i) bytes[address+i] = p[i];
    }
    bool read(Address address, void* out, std::size_t size) const override {
        auto p = static_cast<unsigned char*>(out);
        for (std::size_t i=0; i<size; ++i) {
            auto it = bytes.find(address+i);
            if (it == bytes.end()) return false;
            p[i] = it->second;
        }
        return true;
    }
};
int failures = 0;
void check(bool result, const char* message) {
    if (!result) { ++failures; std::cerr << "FAIL: " << message << '\n'; }
}
}
int main() {
    Fixture memory;
    memory.put<Address>(0x1010,0x2000); memory.put<Address>(0x2028,0x3000);
    memory.put<std::int32_t>(0x2030,0); memory.put<std::int32_t>(0x3010,1);
    memory.put<Address>(0x3018,0x4000); memory.put<Address>(0x3020,0x5000);
    memory.put<Address>(0x3030,0x6000); memory.put<Address>(0x6000,0x2000);
    memory.put<std::int32_t>(0x5000,-1);
    memory.put<TransformTRS>(0x4000, {{1,2,3,0},{0,0,0,1},{1,1,1,0}});
    JointAddresses addresses{};
    addresses[static_cast<std::size_t>(Joint::head)] = 0x1000;
    addresses[static_cast<std::size_t>(Joint::neck)] = 0x9000;
    const auto sampled = read_skeleton(memory, addresses);
    const auto head = sampled[static_cast<std::size_t>(Joint::head)];
    check(head && head->x == 1 && head->y == 2 && head->z == 3, "sample a valid transform");
    check(!sampled[static_cast<std::size_t>(Joint::neck)], "omit unreadable transform");
    check(!sampled[static_cast<std::size_t>(Joint::pelvis)], "omit missing transform");
    Skeleton skeleton{};
    for (auto& joint : skeleton) joint = Vec3{0,0,10};
    Camera camera{{0,0,0},{1,0,0},{0,1,0},{0,0,1},90};
    auto lines = skeleton_lines(skeleton,camera,200,100);
    check(lines.size() == 18, "draw all documented segments");
    check(!lines.empty() && std::fabs(lines[0].from.x-100) < 0.001f &&
          std::fabs(lines[0].from.y-50) < 0.001f, "project line endpoint");
    skeleton[static_cast<std::size_t>(Joint::head)] = Vec3{0,0,-1};
    check(skeleton_lines(skeleton,camera,200,100).size() == 17, "omit behind-camera bone");
    skeleton[static_cast<std::size_t>(Joint::chest)].reset();
    check(skeleton_lines(skeleton,camera,200,100).size() == 13, "omit segments touching missing bone");
    check(skeleton_lines(skeleton,camera,0,100).empty(), "reject invalid viewport");
    if (!failures) std::cout << "All ESP checks passed\n";
    return failures ? 1 : 0;
}
