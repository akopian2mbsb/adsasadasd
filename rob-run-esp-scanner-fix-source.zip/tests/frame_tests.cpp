#include "rob_run/frame.hpp"
#include <cstdint>
#include <iostream>
#include <map>
using namespace rob_run;
namespace {
class Memory final : public MemoryReader {
public:
    std::map<Address,unsigned char> bytes;
    template<class T> void put(Address a,const T& v) { auto p=reinterpret_cast<const unsigned char*>(&v); for (std::size_t i=0;i<sizeof(T);++i) bytes[a+i]=p[i]; }
    bool read(Address a,void* out,std::size_t n) const override { auto p=static_cast<unsigned char*>(out); for(std::size_t i=0;i<n;++i) { auto it=bytes.find(a+i); if(it==bytes.end()) return false; p[i]=it->second; } return true; }
};
struct Entry { std::int32_t hash,next,key,padding; Address value; };
int fails=0;
void check(bool ok,const char* name) { if(!ok) { ++fails; std::cerr << "FAIL " << name << '\n'; } }
}
int main() {
    Memory m;
    m.put<Address>(0x1028,0x2000); m.put<Address>(0x20d0,0x3000); m.put<Address>(0x3010,0x4000);
    m.put<Address>(0x4090,0x5000); m.put<Address>(0x5060,0x6000); m.put<Address>(0x6018,0x7000);
    m.put<Address>(0x50d0,0x8000); m.put<Address>(0x8020,0x9000);
    m.put<Address>(0x2090,0xa000); m.put<Address>(0xa020,0xb000); m.put<Address>(0xb050,0xc000);
    m.put<Address>(0xc018,0xd000); m.put<Address>(0xd0e0,0x4000); m.put<Address>(0xd090,0xe000);
    m.put<Address>(0xd1c0,0xf000); m.put<Address>(0xe018,0x5000); m.put<Address>(0xe110,0x10000);
    m.put<Address>(0xf030,0x5000); m.put<Address>(0xf048,0x11000); m.put<Address>(0x4358,0x12000);
    m.put<Vec3>(0x12010,{0,0,0}); m.put<Vec3>(0x1203c,{0,0,1}); m.put<Vec3>(0x12048,{1,0,0}); m.put<Vec3>(0x12054,{0,1,0}); m.put<float>(0x110b0,90);
    m.put<Address>(0x7018,0x13000); m.put<std::uint32_t>(0x7020,3); m.put<std::uint64_t>(0x13018,3);
    m.put<Entry>(0x13020,{1,-1,1,0,0x9000}); m.put<Entry>(0x13038,{2,-1,2,0,0x14000}); m.put<Entry>(0x13050,{3,-1,3,0,0x15000});
    m.put<std::int32_t>(0x14038,2); m.put<Address>(0x14058,0x16000); m.put<Vec3>(0x16010,{1,2,10});
    m.put<std::int32_t>(0x15038,99);
    auto frame=read_esp_frame(m,0x1000);
    check(frame && frame->positions.size()==1 && frame->positions[0].z==10,"one remote player and no local player");
    if(frame && !frame->positions.empty()) { auto p=project(frame->camera,frame->positions[0],200,100); check(p && p->x>100 && p->y<50,"project collected player"); }
    m.put<Address>(0xd1c0,0);
    check(!read_esp_frame(m,0x1000),"reject missing updater");
    if (!fails) std::cout << "ESP frame integration fixture passed\n";
    return fails ? 1 : 0;
}
