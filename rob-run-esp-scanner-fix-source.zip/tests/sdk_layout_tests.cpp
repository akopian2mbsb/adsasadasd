#include "rob_run/game_state.hpp"

#include <cstdint>
#include <iostream>
#include <limits>
#include <map>

using namespace rob_run;
namespace {
class Memory final : public MemoryReader {
public:
    std::map<Address, unsigned char> bytes;
    template<class T> void put(Address addr, const T& val) {
        auto p = reinterpret_cast<const unsigned char*>(&val);
        for (std::size_t i=0; i<sizeof(T); ++i) bytes[addr+i] = p[i];
    }
    bool read(Address addr, void* dest, std::size_t size) const override {
        auto p = static_cast<unsigned char*>(dest);
        for (std::size_t i=0; i<size; ++i) {
            auto it=bytes.find(addr+i); if (it==bytes.end()) return false; p[i]=it->second;
        }
        return true;
    }
};
struct Entry { std::int32_t hash, next, key, padding; Address value; };
int errors=0;
void check(bool ok, const char* text) { if (!ok) { ++errors; std::cerr << "FAIL " << text << '\n'; } }
}
int main() {
    Memory m;
    BattleState state{0x4000,0x5000,0x7000,0x9000};
    m.put<Address>(0x1028,0x2000); m.put<Address>(0x2090,0x3000);
    m.put<Address>(0x3020,0x3100); m.put<Address>(0x3150,0x3200); m.put<Address>(0x3218,0xa000);
    m.put<Address>(0xa0e0,0x4000); m.put<Address>(0xa090,0xb000); m.put<Address>(0xa1c0,0xc000);
    m.put<Address>(0xb018,0x5000); m.put<Address>(0xb110,0xd000);
    m.put<Address>(0xc030,0x5000); m.put<Address>(0xc048,0xe000);
    auto views=read_entry_views(m,state,0x1000);
    check(views && views->camera_brain==0xe000 && views->character_views_dictionary==0xd000,
          "resolve battle views through current screen");
    m.put<Address>(0xa0e0,0x1111);
    check(!read_entry_views(m,state,0x1000), "reject mismatched battle updater");
    m.put<Address>(0xa0e0,0x4000);
    m.put<Address>(0x4358,0xf000);
    m.put<Vec3>(0xf010,{1,2,3}); m.put<Vec3>(0xf03c,{0,0,1});
    m.put<Vec3>(0xf048,{1,0,0}); m.put<Vec3>(0xf054,{0,1,0}); m.put<float>(0xe0b0,90);
    if (views) {
        const auto camera=read_camera(m,state,*views);
        check(camera && camera->position.x==1 && camera->forward.z==1 && camera->vertical_fov_degrees==90,
              "read model basis and brain FOV");
        m.put<float>(0xe0b0,std::numeric_limits<float>::quiet_NaN());
        check(!read_camera(m,state,*views), "reject nonfinite FOV");
    }
    m.put<Address>(0x11118,0x12000); m.put<std::uint32_t>(0x11120,3);
    m.put<std::uint64_t>(0x12018,4);
    m.put<Entry>(0x12020,{1,-1,7,0,0x18000});
    m.put<Entry>(0x12038,{-1,-1,8,0,0});
    m.put<Entry>(0x12050,{2,-1,9,0,0x19000});
    auto entries=read_entity_dictionary(m,0x11100);
    check(entries && entries->size()==2 && (*entries)[0].first==7 && (*entries)[1].second==0x19000,
          "read active entries and ignore deleted slots");
    m.put<Entry>(0x12050,{2,-1,7,0,0x19000});
    check(!read_entity_dictionary(m,0x11100), "reject duplicate active keys");
    m.put<std::uint64_t>(0x12018,2);
    check(!read_entity_dictionary(m,0x11100), "reject count exceeding capacity");
    m.put<std::uint32_t>(0x11120,65537);
    check(!read_entity_dictionary(m,0x11100), "reject excessive count");
    m.put<std::uint32_t>(0x11120,0);
    entries=read_entity_dictionary(m,0x11100);
    check(entries && entries->empty(), "accept empty dictionary");
    if (!errors) std::cout << "All SDK layout checks passed\n";
    return errors ? 1 : 0;
}
