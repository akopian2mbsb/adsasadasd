#include "rob_run/geometry.hpp"

#include <cmath>
#include <cstdint>
#include <cstring>
#include <iostream>
#include <limits>
#include <map>
#include <vector>

using namespace rob_run;
namespace {
int failures = 0;
void check(bool value, const char* message) {
    if (!value) { std::cerr << "FAIL: " << message << '\n'; ++failures; }
}
bool close(float a, float b) { return std::fabs(a-b) < 0.0001f; }
class TestMemory final : public MemoryReader {
public:
    std::map<Address, unsigned char> data;
    template<class T> void put(Address address, const T& value) {
        const auto* p = reinterpret_cast<const unsigned char*>(&value);
        for (std::size_t i=0; i<sizeof(T); ++i) data[address+i] = p[i];
    }
    template<class T> void put_array(Address address, const std::vector<T>& values) {
        for (std::size_t i=0; i<values.size(); ++i) put(address+i*sizeof(T), values[i]);
    }
    bool read(Address address, void* dst, std::size_t size) const override {
        auto* bytes = static_cast<unsigned char*>(dst);
        for (std::size_t i=0; i<size; ++i) {
            auto it = data.find(address+i);
            if (it == data.end()) return false;
            bytes[i] = it->second;
        }
        return true;
    }
};
TransformTRS trs(float x, float y, float z) {
    return {{x,y,z,0}, {0,0,0,1}, {1,1,1,0}};
}
TestMemory fixture() {
    TestMemory m;
    m.put<Address>(0x1010, 0x2000); m.put<Address>(0x2028, 0x3000); m.put<std::int32_t>(0x2030, 1);
    m.put<std::int32_t>(0x3010, 2); m.put<Address>(0x3018, 0x4000);
    m.put<Address>(0x3020, 0x5000); m.put<Address>(0x3030, 0x6000);
    m.put<Address>(0x6008, 0x2000);
    auto parent = trs(10,20,30);
    parent.scale[0] = 2; parent.scale[1] = 3;
    parent.rotation[2] = std::sqrt(0.5f); parent.rotation[3] = std::sqrt(0.5f);
    m.put_array(0x4000, std::vector<TransformTRS>{parent, trs(1,2,3)});
    m.put_array(0x5000, std::vector<std::int32_t>{-1,0});
    return m;
}
}
int main() {
    auto m = fixture();
    auto p = bone_world_position(m, 0x1000);
    check(p && close(p->x,4) && close(p->y,22) && close(p->z,33), "parent scale, rotation, translation");
    m.put<std::int32_t>(0x5000, 1);
    check(!bone_world_position(m,0x1000), "reject cyclic hierarchy");
    m = fixture(); m.put<Address>(0x6008, 0x1234);
    check(!bone_world_position(m,0x1000), "reject mismatched native pointer");
    m = fixture(); m.put<std::int32_t>(0x5004, 2);
    check(!bone_world_position(m,0x1000), "reject out of bounds parent");
    m = fixture(); m.put<std::int32_t>(0x3010, 4097);
    check(!bone_world_position(m,0x1000), "reject excessive hierarchy");
    m = fixture(); m.put<float>(0x4000, std::numeric_limits<float>::quiet_NaN());
    check(!bone_world_position(m,0x1000), "reject non-finite parent");
    m = fixture(); m.data.erase(0x4001);
    check(!bone_world_position(m,0x1000), "reject incomplete reads");
    m = fixture(); m.put<Address>(0x7008, 0x7100); m.put<Address>(0x7110, 0x7200);
    auto root = follow_pointers(m, 0x7000, {8,16});
    check(root && *root == 0x7200, "follow pointer chain");
    check(!follow_pointers(m, 0x7000, {8,24}), "reject unreadable chain");
    check(!follow_pointers(m, std::numeric_limits<Address>::max()-3, {8}), "reject address overflow");

    Camera c{{0,0,0},{1,0,0},{0,1,0},{0,0,1},90};
    auto screen = project(c, {1,1,1}, 200, 100);
    check(screen && close(screen->x,150) && close(screen->y,0), "project using vertical FOV and aspect");
    check(!project(c,{0,0,0.05f},200,100), "reject near plane");
    check(!project(c,{0,0,-1},200,100), "reject behind camera");
    check(!project(c,{0,0,1},200,0), "reject invalid viewport");
    c.vertical_fov_degrees = 180;
    check(!project(c,{0,0,1},200,100), "reject invalid FOV");
    if (!failures) std::cout << "All geometry checks passed\n";
    return failures ? 1 : 0;
}
